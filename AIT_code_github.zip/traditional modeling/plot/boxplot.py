import pandas as pd
import matplotlib.pyplot as plt

file_names = ['../model/SVR/test/SVR_evaluation_results(linear).xlsx',
              '../model/Lasso/test/lasso_evaluation_results.xlsx',
              '../model/ANN/test/ANN_evaluation_results.xlsx']
model_names=['SVR','MLR','ANN']
sheets = ['Test Results', 'Train Results']
metrics = ['MAE', 'RMSE', 'R2', 'AARE']
data = {}

for file_name in file_names:
    model_name = file_name.split('/')[-1].split('_')[0]
    data[model_name] = {}

    for sheet in sheets:
        df = pd.read_excel(file_name, sheet_name=sheet)
        data[model_name][sheet]={}

        for metric in metrics:
            values = df[metric].values
            data[model_name][sheet][metric] = values

plt.style.use('classic')
plt.rcParams["font.family"] = "Times New Roman"
fig, axes = plt.subplots(nrows=2, ncols=2)

for i, metric in enumerate(metrics):
    temp_data = []
    for j, model_name in enumerate(data.keys()):
        train_values = data[model_name]['Train Results'][metric]
        test_values = data[model_name]['Test Results'][metric]
        temp_data.append(train_values)
        temp_data.append(test_values)

    ax = axes[i//2, i%2]
    bp = ax.boxplot(temp_data)

    boxprops1 = {'linewidth': 1, 'color': 'blue'}
    boxprops2 = {'linewidth': 1, 'color': 'red'}
    for k in [0, 2, 4]:
        plt.setp(bp['boxes'][k], **boxprops1)
    for k in [1, 3, 5]:
        plt.setp(bp['boxes'][k], **boxprops2)

    medianprops = {'color': 'black', 'linewidth': 1}
    flierprops = {'marker': 'o', 'markersize': 4, 'markerfacecolor':'none','markeredgecolor':'black'}
    capprops = {'linewidth': 1}
    whiskerprops = {'color': 'black','linewidth': 1}

    plt.setp(bp['medians'], **medianprops)
    plt.setp(bp['fliers'], **flierprops)
    plt.setp(bp['caps'], **capprops)
    plt.setp(bp['whiskers'], linestyle='--', dashes=(3, 2), **whiskerprops)

    xticklabels = model_names
    ax.set_xticks([1.5, 3.5, 5.5])
    ax.set_xticklabels(xticklabels)
    ax.tick_params(axis='x', which='both', top=False,length=2)
    ax.tick_params(axis='y', which='both', right=False, length=2)

    if metric=='R2':
        metric='R$^2$ [-]'
    if metric=='AARE':
        metric='AARE [-]'
    if metric == 'MAE':
        metric = 'MAE [K]'
    if metric=='RMSE':
        metric='RMSE [K]'
    ax.set_title(metric)

    train_legend = plt.Line2D([], [], color='blue', linewidth=1)
    test_legend = plt.Line2D([], [], color='red', linewidth=1)
    legend=ax.legend([train_legend, test_legend], ['Train Results', 'Test Results'],loc='best',fontsize=10)
    legend.set_frame_on(False)
    legend.get_frame().set_alpha(0)

fig.tight_layout()
plt.savefig('QSPR-boxplot.png',dpi=300)
plt.show()