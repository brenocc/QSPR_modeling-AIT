import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.ticker import ScalarFormatter

df=pd.read_csv('./model_performance(hidden=8).csv')
x=df['Num_features'].to_list()
mse_array=np.array(df['mse'].apply(eval).to_list())
print(mse_array)
max_mse=np.max(mse_array,axis=1)
min_mse=np.min(mse_array,axis=1)
mean_mse=np.mean(mse_array,axis=1)

plt.style.use('classic')
plt.rc('font',family='Times New Roman')
plt.rcParams['font.size'] = 20

plt.errorbar(x, mean_mse, yerr=[mean_mse-min_mse,max_mse - mean_mse], fmt='o', color='red'
             , ecolor='blue', capsize=4,elinewidth=2,capthick=0.5)

plt.xlabel('No. of features [-]')
plt.ylabel('MSE [K$^2$]')
plt.tick_params(axis='both', direction='in', length=3, width=1,top=False, right=False)
plt.xlim(0,127)
formatter = ScalarFormatter(useMathText=True)
formatter.set_powerlimits((-3, 3))
plt.gca().yaxis.set_major_formatter(formatter)


plt.savefig('errorbar1.png',dpi=300)
plt.show()