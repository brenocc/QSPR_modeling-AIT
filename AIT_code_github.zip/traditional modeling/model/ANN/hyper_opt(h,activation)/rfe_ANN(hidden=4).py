# Get Top K The Least Important Features and Retrain
import numpy as np
import pandas as pd
import torch
from captum.attr import IntegratedGradients
from sklearn.model_selection import KFold, train_test_split
from sklearn.preprocessing import MinMaxScaler
from torch import nn
from torch.utils import data

random_seed = 0


class Dataset(torch.utils.data.Dataset):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y

    def __getitem__(self, idx):
        return self.x[idx], self.y[idx]

    def __len__(self):
        return len(self.x)


def calculate_feat_imp(df_init_X, y, epochs):
    X = df_init_X.values
    y = y.values
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=random_seed)

    scaler = MinMaxScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    # define the train and test dataloader
    train_loader = torch.utils.data.DataLoader(Dataset(X_train, y_train))
    test_loader = torch.utils.data.DataLoader(Dataset(X_test, y_test))

    torch.manual_seed(1)

    # Code a neural network with the nn module imported into the class
    class base_Model(nn.Module):
        def __init__(self):
            super().__init__()
            self.linear1 = nn.Linear(X.shape[1], 4)
            self.Relu = nn.ReLU()
            self.linear2 = nn.Linear(4, 1)

        def forward(self, x):
            lin1_out = self.linear1(x)
            Relu_out = self.Relu(lin1_out)
            lin2_out = self.linear2(Relu_out)

            return lin2_out

    model = base_Model()
    criterion = torch.nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
    total_loss, total_acc = list(), list()
    num_epochs = epochs

    for epoch in range(num_epochs):
        losses = 0
        for idx, (x, y) in enumerate(train_loader):
            x, y = x.float(), y.type(torch.float)
            x.requires_grad = True
            optimizer.zero_grad()
            # Check if the program can be run with model(x) and model.forward()
            preds = model.forward(x)
            loss = criterion(preds, y)
            x.requires_grad = False
            loss.backward()
            optimizer.step()
            losses += loss.item()
        total_loss.append(losses / len(train_loader))
        if epoch % 20 == 0:
            print("Epoch:", str(epoch + 1), "\tLoss:", total_loss[-1])

    model.eval()
    mae = 0.0
    total_samples = 0
    for idx, (x, y) in enumerate(test_loader):
        with torch.no_grad():
            x, y = x.float(), y.type(torch.float)
            pred = model(x)
            mae += torch.sum(torch.abs(pred - y))
            total_samples += x.size(0)
    mae /= total_samples
    print("Test set MAE:", mae.item())

    model.eval()
    mae = 0.0
    total_samples = 0
    for idx, (x, y) in enumerate(train_loader):
        with torch.no_grad():
            x, y = x.float(), y.type(torch.float)
            pred = model(x)
            mae += torch.sum(torch.abs(pred - y))
            total_samples += x.size(0)
    mae /= total_samples
    print("Train set MAE:", mae.item())

    test_input_tensor = torch.from_numpy(X_test).type(torch.FloatTensor)
    ig = IntegratedGradients(model)
    test_input_tensor.requires_grad_()
    attr, delta = ig.attribute(test_input_tensor, target=0, return_convergence_delta=True)
    attr = attr.detach().numpy()
    feat_imp = np.mean(np.abs(attr), axis=0)

    return feat_imp


def make_new_dataset(df_init_X, y, feat_imp, k_features):
    feature_names = df_init_X.columns.to_list()
    features_to_be_dropped = [b for (a, b) in sorted(zip(feat_imp, feature_names))][0:k_features]
    # Drop k the least important features
    df_X = df_init_X.drop(features_to_be_dropped, axis=1)
    X = df_X.values
    y = y.values

    scaler = MinMaxScaler()
    X = scaler.fit_transform(X)

    # Create a cross validation object
    kfold = KFold(n_splits=5, random_state=random_seed)

    loaders = []

    for fold, (train_idx, test_idx) in enumerate(kfold.split(X)):
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]

        train_dataset = Dataset(X_train, y_train)
        test_dataset = Dataset(X_test, y_test)
        train_loader = torch.utils.data.DataLoader(train_dataset)
        test_loader = torch.utils.data.DataLoader(test_dataset)

        loaders.append((train_loader, test_loader))

    return loaders, df_X


def define_model(df_X):
    input_dim = df_X.shape[1]
    torch.manual_seed(1)

    # code a neural network with the nn module imported into the class
    class jbchen_Model(nn.Module):
        def __init__(self):
            super().__init__()
            self.linear1 = nn.Linear(input_dim, 4)  # since features have been dropped chaneg input layer
            self.Relu = nn.ReLU()
            self.linear2 = nn.Linear(4, 1)

        def forward(self, x):
            lin1_out = self.linear1(x)
            Relu_out = self.Relu(lin1_out)
            lin2_out = self.linear2(Relu_out)

            return lin2_out

    return jbchen_Model


def train_model(jbchen_Model, train_loader, epochs):
    model = jbchen_Model()
    criterion = torch.nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
    total_loss, total_acc = list(), list()

    num_epochs = epochs

    for epoch in range(num_epochs):
        losses = 0
        for idx, (x, y) in enumerate(train_loader):
            x, y = x.float(), y.type(torch.float)
            x.requires_grad = True
            optimizer.zero_grad()
            # check if the progrma can be run with model(x) and model.forward()
            preds = model.forward(x)
            loss = criterion(preds, y)
            x.requires_grad = False
            loss.backward()
            optimizer.step()
            losses += loss.item()
        total_loss.append(losses / len(train_loader))
        if epoch % 20 == 0:
            print("Epoch:", str(epoch + 1), "\tLoss:", total_loss[-1])
    return model


def test_results(model, test_loader):
    model.eval()
    mae = 0.0
    mse = 0.0
    total_samples = 0
    for idx, (x, y) in enumerate(test_loader):
        with torch.no_grad():
            x, y = x.float(), y.type(torch.float)
            pred = model(x)
            mae += torch.sum(torch.abs(pred - y))
            mse += torch.sum((pred - y) ** 2)
            total_samples += x.size(0)
    mae /= total_samples
    mse /= total_samples
    return mae.item(), mse.item()


file_dir = '../../../../data/init_data.xlsx'
df_init = pd.read_excel(file_dir, 'Pre_screening')
df_init_X = df_init.iloc[:, 10:]
y = df_init['AIT (K)']
a = 3  # Remove the least important features each time

model_performance = pd.DataFrame(columns=['Num_features', 'mae', 'mse'])
for i, _ in enumerate(range(0, 126, a)):
    if i == 0:
        k_features = 0
    else:
        k_features = a
    feat_imp = calculate_feat_imp(df_init_X, y, 200)
    loaders, df_X = make_new_dataset(df_init_X, y, feat_imp, k_features)
    jbchen_Model = define_model(df_X)
    mae_list = []
    mse_list = []
    for train_loader, test_loader in loaders:
        trained_model = train_model(jbchen_Model, train_loader, 200)
        mae, mse = test_results(trained_model, test_loader)
        mae_list.append(mae)
        mse_list.append(mse)
    df_init_X = df_X
    model_performance = model_performance._append({'Num_features': 126 - k_features * i,
                                                   'mae': mae_list, 'mse': mse_list},
                                                  ignore_index=True)
model_performance.to_csv('model_performance(hidden=4).csv', index=False)
