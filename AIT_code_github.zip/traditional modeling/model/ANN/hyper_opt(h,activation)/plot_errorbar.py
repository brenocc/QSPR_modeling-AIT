import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

dfs = []
for i in range(4, 10):
    df = pd.read_csv(f"./model_performance(hidden={i}).csv")
    dfs.append(df)

plt.style.use('classic')
plt.rc('font', family='Times New Roman')
plt.rcParams['font.size'] = 14

fig, axs = plt.subplots(nrows=3, ncols=3, figsize=(12, 8))
axs = axs.ravel()

# Hidden layer neuron subgraph
for i in range(6):
    ax = axs[i]
    x = dfs[i]['Num_features'].to_list()
    mse_array = np.array(dfs[i]['mse'].apply(eval).to_list())
    max_mse = np.max(mse_array, axis=1)
    min_mse = np.min(mse_array, axis=1)
    mean_mse = np.mean(mse_array, axis=1)

    ax.errorbar(x, mean_mse, yerr=[mean_mse - min_mse, max_mse - mean_mse], ms=3, fmt='o', color='black',
                ecolor='blue', capsize=3, elinewidth=1, capthick=1)

    ax.set_xlabel('No. of Features [-]')
    ax.set_ylabel('MSE [K$^2$]')
    ax.set_title(f"h = {i + 4}")

# Activation function subgraph
for j, activation in enumerate(['ReLU', 'Sigmoid', 'Tanh']):
    ax = axs[6 + j]
    df = pd.read_csv(f"./model_performance({activation}).csv")
    x = df['Num_features'].to_list()
    mse_array = np.array(df['mse'].apply(eval).to_list())
    max_mse = np.max(mse_array, axis=1)
    min_mse = np.min(mse_array, axis=1)
    mean_mse = np.mean(mse_array, axis=1)

    ax.errorbar(x, mean_mse, yerr=[mean_mse - min_mse, max_mse - mean_mse], ms=3, fmt='o', color='black',
                ecolor='blue', capsize=3, elinewidth=1, capthick=1)

    ax.set_xlabel('No. of Features [-]')
    ax.set_ylabel('MSE [K$^2$]')
    ax.set_title(f"{activation} ")

plt.tight_layout()
plt.savefig('errorbar.png', dpi=300)
plt.show()
