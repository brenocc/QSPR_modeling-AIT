import numpy as np
import pandas as pd
from matplotlib.ticker import ScalarFormatter
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
from sklearn.linear_model import LassoCV



file_dir = '../../../../data/init_data.xlsx'
df_init = pd.read_excel(file_dir, 'Pre-screening')
X=df_init.iloc[:, 10:].values
y=df_init['AIT (K)'].values

scaler = MinMaxScaler()
X = scaler.fit_transform(X)

alphas = np.logspace(-3, 3, num=100)

lasso_cv = LassoCV(alphas=alphas, cv=5)
lasso_cv.fit(X, y)

mean_mse_path = np.mean(lasso_cv.mse_path_, axis=1)
max_mse_path=np.max(lasso_cv.mse_path_, axis=1)
min_mse_path=np.min(lasso_cv.mse_path_, axis=1)

print(lasso_cv.dual_gap_)

n_features = []
for alpha in alphas:
    lasso = LassoCV(alphas=[alpha], cv=5)
    lasso.fit(X, y)
    n_features.append(np.sum(lasso.coef_ != 0))


plt.style.use('classic')
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams['font.size'] = 20
fig, ax1 = plt.subplots()


color1 = 'tab:red'
ax1.tick_params(direction='in', length=3, width=1, top=False,)
ax1.set_xlabel('Log(\u03BB) [-]')
ax1.set_ylabel('MSE [K$^2$]', color=color1)
ax1.plot(np.log10(lasso_cv.alphas_), mean_mse_path, color=color1, label='Mean MSE',linestyle='--',linewidth=2)
ax1.fill_between(np.log10(lasso_cv.alphas_), min_mse_path, max_mse_path, alpha=0.1, color=color1, label='MSE Interval')
ax1.tick_params(axis='y', labelcolor=color1)
ax1.yaxis.set_major_formatter(ScalarFormatter(useMathText=True))
ax1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))


ax2 = ax1.twinx()
ax2.tick_params(direction='in', length=3, width=1)
color2 = 'tab:blue'
ax2.set_ylabel('Number of Features [-]', color=color2)
ax2.plot(np.log10(alphas), n_features, color=color2,label='No.of Features',linewidth=2)
ax2.tick_params(axis='y', labelcolor=color2)


lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
lines = lines1 + lines2
labels = labels1 + labels2
legend=ax1.legend(lines, labels,loc='best',fontsize=16)

legend.set_frame_on(False)
legend.get_frame().set_alpha(0)
plt.savefig('best_lambda.png',dpi=300)
plt.show()
