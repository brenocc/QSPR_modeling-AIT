import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Lasso
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

seed = 123
best_alpha = 1
num_trials = 10


# Define a function for evaluating
def evaluate(y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    aare = np.mean(np.abs((y_true - y_pred) / y_true))
    return mae, rmse, r2, aare


file_dir = '../../../../data/init_data.xlsx'
df_init = pd.read_excel(file_dir, 'Pre-screen')
X = df_init.iloc[:, 10:]
y = df_init['AIT (K)']
columns_names = df_init.iloc[:, 10:].columns

maes = []
rmses = []
r2s = []
aares = []

train_maes = []
train_rmses = []
train_r2s = []
train_aares = []

for trial in range(num_trials):
    print(f"Training {trial + 1}/{num_trials}")

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2,
                                                        random_state=seed + trial)  # 改变随机划分的 random_state

    scaler = MinMaxScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    lasso = Lasso(alpha=best_alpha)
    lasso.fit(X_train, y_train)

    # Get the index of the selected feature
    selected_features_idx = lasso.coef_ != 0
    print(selected_features_idx)

    selected_features = X.iloc[:, selected_features_idx]
    new_df = pd.concat([df_init.iloc[:, :10], selected_features], axis=1)
    new_df.to_csv('./sub_features_set_for_training.csv', index=False)

    y_pred = lasso.predict(X_test)
    mae, rmse, r2, aare = evaluate(y_test, y_pred)

    maes.append(mae)
    rmses.append(rmse)
    r2s.append(r2)
    aares.append(aare)

    y_train_pred = lasso.predict(X_train)
    train_mae, train_rmse, train_r2, train_aare = evaluate(y_train, y_train_pred)

    train_maes.append(train_mae)
    train_rmses.append(train_rmse)
    train_r2s.append(train_r2)
    train_aares.append(train_aare)

    plt.scatter(y_test, y_pred, c='r', label='Test Data')

    plt.scatter(y_train, y_train_pred, c='b', label='Train Data')

    plt.plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], 'k--', lw=2)

    plt.title('Scatter Plot')
    plt.xlabel('True Values')
    plt.ylabel('Predicted Values')

    plt.legend()
    plt.close()


df_results = pd.DataFrame({
    'MAE': maes,
    'RMSE': rmses,
    'R2': r2s,
    'AARE': aares
})


df_train_results = pd.DataFrame({
    'MAE': train_maes,
    'RMSE': train_rmses,
    'R2': train_r2s,
    'AARE': train_aares
})


excel_writer = pd.ExcelWriter('lasso_evaluation_results.xlsx', engine='openpyxl')
df_results.to_excel(excel_writer, sheet_name='Test Results', index=False)
df_train_results.to_excel(excel_writer, sheet_name='Train Results', index=False)
excel_writer.close()

print('Results saved to file.')
