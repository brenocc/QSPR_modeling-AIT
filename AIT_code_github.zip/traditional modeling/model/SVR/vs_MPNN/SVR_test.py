import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.svm import SVR

seed = 123
best_alpha = 1
num_trials = 10


# Define a function for evaluating
def evaluate(y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    aare = np.mean(np.abs((y_true - y_pred) / y_true))
    return mae, rmse, r2, aare


df_init = pd.read_csv("../features_selection/sub_features_set_for_training.csv")
X = df_init.iloc[:, 10:].values
y = df_init['AIT (K)'].values
columns_names = df_init.iloc[:, 10:].columns

maes = []
rmses = []
r2s = []
aares = []

train_maes = []
train_rmses = []
train_r2s = []
train_aares = []

val_maes = []
val_rmses = []
val_r2s = []
val_aares = []

for trial in range(num_trials):
    print(f"Training {trial + 1}/{num_trials}")

    X_train, X_mid, y_train, y_mid = train_test_split(X, y, test_size=0.2, random_state=seed + trial)
    X_val, X_test, y_val, y_test = train_test_split(X_mid, y_mid, test_size=0.5, random_state=seed + trial)

    scaler = MinMaxScaler()
    X_train = scaler.fit_transform(X_train)
    X_val = scaler.transform(X_val)
    X_test = scaler.transform(X_test)

    regressor = SVR(kernel='rbf', gamma='scale',
                    C=100, epsilon=10)
    regressor.fit(X_train, y_train)

    y_pred = regressor.predict(X_test)
    mae, rmse, r2, aare = evaluate(y_test, y_pred)
    maes.append(mae)
    rmses.append(rmse)
    r2s.append(r2)
    aares.append(aare)

    y_train_pred = regressor.predict(X_train)
    train_mae, train_rmse, train_r2, train_aare = evaluate(y_train, y_train_pred)
    train_maes.append(train_mae)
    train_rmses.append(train_rmse)
    train_r2s.append(train_r2)
    train_aares.append(train_aare)

    y_val_pred = regressor.predict(X_val)
    val_mae, val_rmse, val_r2, val_aare = evaluate(y_val, y_val_pred)
    val_maes.append(val_mae)
    val_rmses.append(val_rmse)
    val_r2s.append(val_r2)
    val_aares.append(val_aare)

    plt.scatter(y_test, y_pred, c='r', label='Test Data')
    plt.scatter(y_train, y_train_pred, c='b', label='Train Data')
    plt.scatter(y_val, y_val_pred, c='green', label='val Data')
    plt.plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], 'k--', lw=2)

    plt.title('Scatter Plot')
    plt.xlabel('True Values')
    plt.ylabel('Predicted Values')

    plt.legend()
    plt.close()

df_results = pd.DataFrame({
    'MAE': maes,
    'RMSE': rmses,
    'R2': r2s,
    'AARE': aares
})

df_train_results = pd.DataFrame({
    'MAE': train_maes,
    'RMSE': train_rmses,
    'R2': train_r2s,
    'AARE': train_aares
})

df_val_results = pd.DataFrame({
    'MAE': val_maes,
    'RMSE': val_rmses,
    'R2': val_r2s,
    'AARE': val_aares
})


excel_writer = pd.ExcelWriter('SVR_evaluation_results.xlsx', engine='openpyxl')
df_results.to_excel(excel_writer, sheet_name='test', index=False)
df_train_results.to_excel(excel_writer, sheet_name='train', index=False)
df_val_results.to_excel(excel_writer, sheet_name='val', index=False)

excel_writer.close()

print('Results saved to file.')
