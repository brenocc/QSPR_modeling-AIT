import numpy as np
import pandas as pd
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

df = pd.read_csv('../features_selection/sub_features_set_for_training.csv')
X = df[df.columns[10:]]
y = df['Priority'].values

tsne = TSNE(n_components=2)
X_tsne = tsne.fit_transform(X)

unique_labels = pd.unique(y)
colors = plt.cm.rainbow(np.linspace(0, 1, len(unique_labels)))
markers = ['o', 's', '^', 'D', '*', 'v']

plt.style.use('classic')
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams['font.size'] = 20
for i, label in enumerate(unique_labels):
    mask = (y == label)
    if i == 0:
        plt.scatter(X_tsne[mask, 0], X_tsne[mask, 1], color=colors[i], edgecolors=colors[i], marker=markers[i],
                    label=label)
    else:
        plt.scatter(X_tsne[mask, 0], X_tsne[mask, 1], color='none', edgecolors=colors[i], marker=markers[i],
                    label=label)

plt.xlabel('t-SNE Dimension 1')
plt.ylabel('t-SNE Dimension 2')
plt.title('t-SNE Visualization')

legend = plt.legend(prop={'size': 16})
legend.set_frame_on(False)
legend.get_frame().set_alpha(0)

plt.savefig('2d-tSNE.png', dpi=300)
plt.show()
