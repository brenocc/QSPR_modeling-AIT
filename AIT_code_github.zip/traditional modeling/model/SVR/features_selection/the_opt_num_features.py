import numpy as np
import pandas as pd
from sklearn.feature_selection import RFECV
from sklearn.preprocessing import MinMaxScaler
from sklearn.svm import SVR
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter

file_dir = '../../../../data/init_data.xlsx'
df_init = pd.read_excel(file_dir, 'Pre-screening')
X = df_init.iloc[:, 10:].values
y = df_init['AIT (K)'].values
num_features = X.shape[1]

k = 5

scaler = MinMaxScaler()
X = scaler.fit_transform(X)

C = 100
epsilon = 10


plt.style.use('classic')
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 20


base_model = SVR(kernel="linear", C=C, epsilon=epsilon)
rfecv = RFECV(estimator=base_model, scoring='neg_mean_squared_error', cv=k, step=3)
rfecv.fit(X, y)


selected_feature_indices = rfecv.get_support(indices=True)
selected_feature_names = df_init.iloc[:, 10:].columns[selected_feature_indices]
df_selected_features = df_init[selected_feature_names]
selected_data=df_init.iloc[:, :10].join(df_selected_features)
selected_data.to_csv('./sub_features_set_for_training.csv', index=False)

print(f"Optimal number of features: {rfecv.n_features_}")
n_subsets_of_features = rfecv.cv_results_['split0_test_score'].shape[0]


result_array = np.empty((n_subsets_of_features, k))

for _ in range(k):
    key = 'split{}_test_score'.format(_)
    result_array[:, _] = rfecv.cv_results_[key]

min_result = -np.max(result_array, axis=1)
max_result = -np.min(result_array, axis=1)
mean_squared_error = -rfecv.cv_results_['mean_test_score']

x1 = range(3, num_features + 1, 3)
y1 = mean_squared_error[1:]

plt.figure()
plt.tick_params(axis='both', which='both', bottom=True, top=False,
               left=True, right=False, direction='in', length=3, width=1)
plt.errorbar(x1, y1, yerr=[max_result[1:] - mean_squared_error[1:],
                          mean_squared_error[1:] - min_result[1:]],
            fmt='o',ecolor='r',color='b',elinewidth=2,capsize=4,capthick=0.5)

plt.xlabel("No. of features [-]")
plt.xlim(0, 127)
plt.ylabel("MSE [K$^2$]")
plt.rcParams['xtick.major.pad'] = 2
plt.rcParams['ytick.major.pad'] = 2

formatter = ScalarFormatter(useMathText=True)
formatter.set_powerlimits((-3, 3))
plt.gca().yaxis.set_major_formatter(formatter)
plt.savefig('rfecv.png', dpi=300)
plt.show()