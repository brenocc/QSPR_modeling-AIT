import numpy as np
import pandas as pd
from sklearn.feature_selection import RFECV
from sklearn.preprocessing import MinMaxScaler
from sklearn.svm import SVR
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter


file_dir = '../../../../data/init_data.xlsx'
df_init = pd.read_excel(file_dir, 'Pre-screening')
X = df_init.iloc[:, 10:].values
y = df_init['AIT (K)'].values
num_features = X.shape[1]

k = 5

scaler = MinMaxScaler()
X = scaler.fit_transform(X)

C_values = [10, 100, 1000]
epsilon_values = [0.1, 1, 10]


plt.style.use('classic')
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 14

fig, axs = plt.subplots(len(C_values), len(epsilon_values), figsize=(12, 8))
plt.subplots_adjust(wspace=0.4, hspace=0.4)

for i, C in enumerate(C_values):
    for j, epsilon in enumerate(epsilon_values):
        base_model = SVR(kernel="linear", C=C, epsilon=epsilon)
        rfecv = RFECV(estimator=base_model, scoring='neg_mean_squared_error', cv=k, step=3)
        rfecv.fit(X, y)
        n_subsets_of_features = rfecv.cv_results_['split0_test_score'].shape[0]

        result_array = np.empty((n_subsets_of_features, k))

        for _ in range(k):
            key = 'split{}_test_score'.format(_)
            result_array[:, _] = rfecv.cv_results_[key]

        min_result = -np.max(result_array, axis=1)

        max_result = -np.min(result_array, axis=1)
        mean_squared_error = -rfecv.cv_results_['mean_test_score']

        x1 = range(0, num_features + 1, 3)
        y1 = mean_squared_error

        ax = axs[i, j]

        ax.tick_params(axis='both', which='both', bottom=True, top=True,
                       left=True, right=True, direction='in', length=2, width=1)
        ax.errorbar(x1, y1, yerr=[max_result - mean_squared_error,
                                  mean_squared_error - min_result],
                    fmt='o', ecolor='r', color='b', elinewidth=0.5, capsize=1, ms=2,capthick=0.5)

        ax.set_xlabel("No. of features [-]")
        ax.set_xlim(0, 126)
        ax.set_ylabel("MSE [K$^2$]")
        ax.set_title("$C={}, \u03B5={}$".format(C, epsilon))
        plt.rcParams['xtick.major.pad'] = 2
        plt.rcParams['ytick.major.pad'] = 2

        formatter = ScalarFormatter(useMathText=True)
        formatter.set_powerlimits((-3, 3))
        ax.yaxis.set_major_formatter(formatter)
plt.savefig('rfecv.png', dpi=300)
plt.show()
