import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from sklearn.metrics import mean_absolute_error

np.random.seed(123)
df = pd.read_csv('../../features_selection/sub_features_set_for_training.csv')
train_df=df[~(df["Priority"] == 5)]
test_df=df[df["Priority"] == 5]

X_train = train_df[train_df.columns[10:]]
y_train = train_df['AIT (K)']
weight_train=train_df['Priority']
X_test = test_df[test_df.columns[10:]]
y_test = test_df['AIT (K)']
weight_test=test_df['Priority']


Scaler = StandardScaler()
Scaler.fit(X=X_train)
X_train = Scaler.transform(X_train)
X_test = Scaler.transform(X_test)

# SVR building
regressor = SVR(kernel='rbf', gamma='scale',
                C=50, epsilon=10)
regressor.fit(X_train, y_train, sample_weight=weight_train)

y_pred = regressor.predict(X_test)
y_trainpred = regressor.predict(X_train)

result_df = pd.DataFrame({'Actual AIT': y_test,
                          'Predicted AIT': y_pred})

result_df.to_csv("./Weighting_training_predictions.csv", index=False)

print("-------------Test set results-------------")

print(mean_absolute_error(y_test, y_pred))

print("-------------Training set results-------------")

print(mean_absolute_error(y_train, y_trainpred))

import matplotlib.pyplot as plt
plt.figure(figsize=(9,7), dpi=100)
plt.rc('font',family='Times New Roman', size=20)
plt.scatter(y_pred, y_test, label="Test Dateset", marker='o', c='#ff7f0e',edgecolors='#ff7f0e', alpha=0.5, s=60)
plt.xlabel('Predicted/K', fontsize=25)
plt.ylabel('Experimental/K', fontsize=25)
plt.xticks()
plt.yticks()
plt.scatter(y_trainpred, y_train, c='#1f77b4', label="Train Dataset", marker='o', edgecolors='#1f77b4', alpha=0.5, s=60)
plt.title('SVR Scatter Plot', fontsize=25)

max_value = max([max(y_pred), max(y_test), max(y_trainpred), max(y_train)])
yy = range(0, int(max_value + 1), 1)
plt.plot(range(0, int(max_value + 1), 1), yy, c='gray')


yy1= list(map(lambda x: x + 30, yy))
plt.plot(range(0, int(max_value + 1), 1), yy1, c='r')
yy1= list(map(lambda x: x - 30, yy))
plt.plot(range(0, int(max_value + 1), 1), yy1, c='r')

plt.legend()
plt.close()
