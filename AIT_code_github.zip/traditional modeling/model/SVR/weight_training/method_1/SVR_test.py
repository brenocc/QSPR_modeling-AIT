import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from sklearn.metrics import mean_absolute_error

np.random.seed(123)
df = pd.read_csv('../../features_selection/sub_features_set_for_training.csv')
train_df=df[~(df["Priority"] == 5)]
test_df=df[df["Priority"] == 5]

X_train = train_df[train_df.columns[10:]]
assert X_train.shape[1]==12
y_train = train_df['AIT (K)']
X_test = test_df[test_df.columns[10:]]
y_test = test_df['AIT (K)']

Scaler = StandardScaler()
Scaler.fit(X=X_train)
X_train = Scaler.transform(X_train)
X_test = Scaler.transform(X_test)

regressor = SVR(kernel='rbf', gamma='scale',
                C=100, epsilon=10)
regressor.fit(X_train, y_train)


y_pred = regressor.predict(X_test)
y_trainpred = regressor.predict(X_train)

result_df = pd.DataFrame({'Actual AIT': y_test,
                          'Predicted AIT': y_pred})

result_df.to_csv("./predictions.csv", index=False)

print("-------------Test set results-------------")

print(mean_absolute_error(y_test, y_pred))

print("-------------Training set results-------------")

print(mean_absolute_error(y_train, y_trainpred))

