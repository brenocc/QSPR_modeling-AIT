import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import pandas as pd
import matplotlib.cm as cm

# Use a ColorBrewer color scheme
colorbrewer_colors = cm.get_cmap('Paired')

df=pd.read_csv('./method_1/predictions.csv')
df_1=pd.read_csv('method_2/Weighting_training_predictions.csv')
y_true = df['Actual AIT']
y_pred_1 = df['Predicted AIT']
y_pred_2 = df_1['Predicted AIT']

plt.style.use('classic')
fig = plt.figure(figsize=(8,8))
gs = fig.add_gridspec(4, 1)
plt.rc('font', family='Times New Roman', size=20)

ax_main = fig.add_subplot(gs[1:, :])
ax_main.scatter(y_true, y_pred_1,color=colorbrewer_colors(1),s=30, label='Method 1',facecolors='none')
ax_main.scatter(y_true, y_pred_2,color=colorbrewer_colors(5),s=30,  label='Method 2')

reg_line_x = np.linspace(min(y_true), max(y_true), 100)
reg_line_y = reg_line_x
ax_main.plot(reg_line_x, reg_line_y,color='black',   linestyle='--',linewidth=2)

mae_no_weight = np.mean(np.abs(y_true - y_pred_1))
mae_sample_weight = np.mean(np.abs(y_true - y_pred_2))

text_pos = (0.95, 0.05)
ax_main.text(text_pos[0], text_pos[1],
             f"MAE(Method 1): {mae_no_weight:.2f}K\n"
             f"MAE(Method 2): {mae_sample_weight:.2f}K",
             horizontalalignment='right',
             verticalalignment='bottom',
             transform=ax_main.transAxes,
             fontsize=16)

legend=ax_main.legend(loc='best',fontsize=16)
legend.set_frame_on(False)
legend.get_frame().set_alpha(0)

ax_main.set_xlabel('Experiment [K]')
ax_main.set_ylabel('Predicted [K]')
ax_main.spines['top'].set_visible(False)
ax_main.tick_params(axis='x', which='both', top=False,length=2)
ax_main.tick_params(axis='y', which='both', right=False,length=2)

error_1 = y_true - y_pred_1
error_2 = y_true - y_pred_2

# Plot a subplot of the error distribution (top)
ax_top = fig.add_subplot(gs[0:1, :])
sns.kdeplot(error_1, color=colorbrewer_colors(1), ax=ax_top,legend=False,linestyle='--',linewidth=2)
sns.kdeplot(error_2, color=colorbrewer_colors(5), ax=ax_top,legend=False,linewidth=2)

ax_top.set_ylabel('Density')

ax_top.spines['top'].set_visible(False)
ax_top.spines['right'].set_visible(False)
ax_top.spines['left'].set_visible(False)
ax_top.spines['bottom'].set_visible(False)

ax_top.set_xticks([])
ax_top.set_yticks([])
gs.update(hspace=0)

# Add legend to ax_main
handles, labels = ax_main.get_legend_handles_labels()
handles_top, labels_top = ax_top.get_legend_handles_labels()
handles.extend(handles_top)
labels.extend(labels_top)
ax_main.legend(handles, labels, loc='best', fontsize=16, frameon=False)

plt.savefig('Weight_influence.png',dpi=300)
plt.show()