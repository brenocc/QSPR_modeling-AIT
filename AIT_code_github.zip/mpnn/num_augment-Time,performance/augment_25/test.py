import pandas as pd
from dgl.dataloading import GraphDataLoader
from torch import nn, optim
from model.MPNN import MPNNEncoder, Regressor
import time
from util import train, test, MolecularDataset, split_dataset, augment

seed = 12
file_dir='../../../data/init_data.xlsx'
df = pd.read_excel(file_dir, 'Pre-screening')
train_df, val_df, test_df = split_dataset(df, seed)
aug_train_df = augment(train_df, 25, seed)

train_data = MolecularDataset(train_df)
train_loader = GraphDataLoader(train_data, batch_size=1, shuffle=True)
aug_train_data = MolecularDataset(aug_train_df)
val_data = MolecularDataset(val_df)
test_data = MolecularDataset(test_df)
aug_train_loader = GraphDataLoader(aug_train_data, batch_size=1, shuffle=True)
val_loader = GraphDataLoader(val_data, batch_size=1, shuffle=True)
test_loader = GraphDataLoader(test_data, batch_size=1, shuffle=True)

node_out_feats = 512
num_step_set2set = 1
num_layer_set2set = 1
num_message_passing = 1

encoder = MPNNEncoder(node_in_feats=177, edge_in_feats=17, node_out_feats=node_out_feats,
                      num_step_set2set=num_step_set2set, num_layer_set2set=num_layer_set2set,
                      num_message_passing=num_message_passing)
regressor = Regressor(input_channels=node_out_feats * 2, hidden_channels=node_out_feats, output_channels=1)
optimizer = optim.Adam(list(encoder.parameters()) + list(regressor.parameters()), lr=0.0001)
criterion = nn.MSELoss()

start_time = time.time()
train(encoder, regressor, aug_train_loader, val_loader, criterion, optimizer, num_epochs=10,
      encod_save_path='./_path/best_MPNN.pth', regre_save_path='./_path/best_MPNN_regressor.pth'
      , step_size=5, gamma=0.1, patience=10)
end_time = time.time()

results = test(encoder, regressor, test_loader, train_loader, val_loader,
               encod_save_path='./_path/best_MPNN.pth',
               regre_save_path='./_path/best_MPNN_regressor.pth')

duration = end_time - start_time
with open('training_results.txt', 'w') as f:
    f.write(f"Time：{duration}s\n")
    f.write(f"Results：{results}")
