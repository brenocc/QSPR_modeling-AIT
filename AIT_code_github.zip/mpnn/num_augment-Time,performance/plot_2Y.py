import matplotlib.pyplot as plt
import re
import numpy as np
from matplotlib.legend_handler import HandlerLine2D
from matplotlib.ticker import ScalarFormatter
from scipy import interpolate
import matplotlib.lines as mlines

i=5
augment_times=[0, 5, 10, 25, 50, 75, 100]
times=[]
performances=[]
for i in augment_times:
    with open('./augment_{}/training_results.txt'.format(i),'r') as data:
        data=data.readlines()
        time=data[0]
        time=re.findall(r'\d+\.\d+',time)
        times.append(float(time[0]))
        performance=data[1]
        performance=eval(performance.strip('Results：'))['test']['RMSE']
        performances.append(performance)

#MSE
performances=[x**2 for x in performances]

dataset_sizes=[i * 640 for i in [1, 6, 11, 26, 51, 76, 101]]

plt.style.use('classic')
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams['font.size'] = 20

fig, ax1 = plt.subplots()
ax2 = ax1.twinx()

p1,=ax1.plot(dataset_sizes, performances, 'o', color='blue', markeredgewidth=1, markersize=7)
p1.set_markerfacecolor('none')
p1.set_markeredgecolor('blue')
# Interpolate and draw a smooth curve
f = interpolate.interp1d(dataset_sizes, performances, kind='cubic')
xnew = np.linspace(dataset_sizes[0], dataset_sizes[-1], 1000)
ax1.plot(xnew, f(xnew), '-', color='blue',linewidth=1)

ax1.set_xlabel('Dataset size')
ax1.set_ylabel('MSE [K$^2$]', color='blue')
ax1.tick_params(direction='in', length=3, width=1, top=False,)
ax1.tick_params(axis='y', colors='blue')
ax1.xaxis.set_major_formatter(ScalarFormatter(useMathText=True))
ax1.ticklabel_format(style='sci', axis='x', scilimits=(0, 0))
ax1.yaxis.set_major_formatter(ScalarFormatter(useMathText=True))
ax1.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))
ax1.set_ylim(3400,4200)

p2,=ax2.plot(dataset_sizes, times, 'o', color='r', markeredgewidth=1, markersize=7)
p2.set_markerfacecolor('none')
p2.set_markeredgecolor('r')

g = interpolate.interp1d(dataset_sizes, times, kind='cubic')
ax2.plot(xnew, g(xnew), '-.', color='r',linewidth=1)
ax2.set_ylabel('Time for model training [s]', color='r')
ax2.tick_params(axis='y', colors='r')
ax2.yaxis.set_major_formatter(ScalarFormatter(useMathText=True))
ax2.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))

ax2.spines['left'].set_color('blue')
ax2.spines['right'].set_color('r')

blue_line = mlines.Line2D([], [], color='blue', marker='o', linestyle='-',markerfacecolor='none', markeredgecolor='blue')
red_line = mlines.Line2D([], [], color='red', marker='o', linestyle='-.',markerfacecolor='none', markeredgecolor='red')
blue_label = 'MSE'
red_label = 'Time '
legend_handles = [blue_line, red_line]
legend_labels = [blue_label, red_label]
handler_map = {mlines.Line2D: HandlerLine2D(numpoints=1)}
legend = plt.legend(handles=legend_handles, labels=legend_labels, loc='best', fontsize=14, handler_map=handler_map)

legend.set_frame_on(False)
legend.get_frame().set_alpha(0)
plt.savefig('Dataset_size-times-MSE.png', dpi=300)
plt.show()





