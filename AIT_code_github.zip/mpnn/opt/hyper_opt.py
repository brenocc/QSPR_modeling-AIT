from itertools import product

import numpy as np
import pandas as pd
import torch
from dgl.dataloading import GraphDataLoader
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.model_selection import KFold

from model.MPNN import MPNNEncoder, Regressor
from util import create_dgl_features, train, MolecularDataset
from torch import nn, optim
seed=123
k=5
encod_save_path= './_path/best_MPNN.pth'
regre_save_path= './_path/best_MPNN_regressor.pth'
result_path='./result/result.csv'

def evaluate(encoder, regressor, loader, encod_save_path, regre_save_path):
    # 加载最佳模型
    encoder.load_state_dict(torch.load(encod_save_path))
    regressor.load_state_dict(torch.load(regre_save_path))

    encoder.eval()
    regressor.eval()
    y_true = []
    y_pred = []
    with torch.no_grad():
        for batch_idx, (graphs, labels) in enumerate(loader):
            node_feats = graphs.ndata['feats']
            edge_feats = graphs.edata['edge_feats']
            h = encoder(graphs, node_feats, edge_feats)
            outputs = regressor(h)

            outputs = outputs.to(torch.float32)
            labels = labels.to(torch.float32)

            y_true.extend(labels.cpu().numpy())
            y_pred.extend(outputs.cpu().numpy())

            y_pred = list(map(float, y_pred))

    mse = mean_squared_error(y_true, y_pred)
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_true, y_pred)
    aare = np.mean(np.abs((np.array(y_true) - np.array(y_pred)) / np.array(y_true)))

    print(' MAE: {:.4f}'.format(mae))
    print('RMSE: {:.4f}'.format(rmse))
    print(' R²: {:.4f}'.format(r2))
    print('AARE: {:.4f}'.format(aare))
    return mse


param_grid = {
    'node_out_feats': [128,256,512],
    'num_step_set2set': [1,2,3],
    'num_layer_set2set': [1, 2,3],
    'num_message_passing': [1,2,3]
}
file_dir='../../data/init_data.xlsx'
df = pd.read_excel(file_dir, 'Pre-screening')
df['graph'] = df['SMILES'].apply(lambda x: create_dgl_features(x))

results = []
best_params = {}

for node_out_feats, num_step_set2set, num_layer_set2set, num_message_passing in product(*param_grid.values()):
    avg_mse= 0

    kf = KFold(n_splits=k, shuffle=True,random_state=seed)
    for train_index, val_index in kf.split(df):
        train_df, val_df = df.iloc[train_index], df.iloc[val_index]
        train_df = train_df.reset_index(drop=True)
        val_df = val_df.reset_index(drop=True)

        train_data = MolecularDataset(train_df)
        val_data = MolecularDataset(val_df)

        train_loader = GraphDataLoader(train_data, batch_size=1, shuffle=True)
        val_loader = GraphDataLoader(val_data, batch_size=1, shuffle=True)

        encoder = MPNNEncoder(node_in_feats=177, edge_in_feats=17, node_out_feats=node_out_feats,
                              num_step_set2set=num_step_set2set, num_layer_set2set=num_layer_set2set,
                              num_message_passing=num_message_passing)
        regressor = Regressor(input_channels=node_out_feats*2, hidden_channels=node_out_feats, output_channels=1)
        optimizer = optim.Adam(list(encoder.parameters()) + list(regressor.parameters()), lr=0.0001)
        criterion = nn.MSELoss()

        train(encoder, regressor, train_loader, val_loader, criterion, optimizer, num_epochs=20,
              encod_save_path=encod_save_path, regre_save_path=regre_save_path)

        mse=evaluate(encoder, regressor, val_loader, encod_save_path, regre_save_path)
        avg_mse += mse

    avg_mse /= k
    results.append({
        'node_out_feats': node_out_feats,
        'num_step_set2set': num_step_set2set,
        'num_layer_set2set': num_layer_set2set,
        'num_message_passing': num_message_passing,
        'mse': avg_mse,
    })
    if not best_params or avg_mse < best_params['mse']:
        best_params = {
            'node_out_feats': node_out_feats,
            'num_step_set2set': num_step_set2set,
            'num_layer_set2set': num_layer_set2set,
            'num_message_passing': num_message_passing,
            'mse': avg_mse,

        }

result_df = pd.DataFrame(results)
result_df.to_csv(result_path, index=False)

print('Best Parameter Combination:')
print(best_params)

