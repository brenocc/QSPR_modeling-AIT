import numpy as np
from dgllife import utils
from rdkit import Chem
from chembl_structure_pipeline import standardizer
import pandas as pd
from torch.optim.lr_scheduler import StepLR
import random
from thansform import RandomAtomMask, RandomBondDelete

import torch
from matplotlib import pyplot as plt
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from torch.utils.data import Dataset


# Converted the RDKit molecular objects to the Bi-directed graphs and featurizerd it
def create_dgl_features(SMILES, bonds=True):
    mol = Chem.MolFromSmiles(SMILES)
    mol = standardizer.standardize_mol(mol)

    if bonds:
        dgl_graph = utils.mol_to_bigraph(mol=mol,
                                         node_featurizer=featurize_atoms,
                                         edge_featurizer=featurize_bonds,
                                         canonical_atom_order=True)
    else:
        dgl_graph = utils.mol_to_bigraph(mol=mol,
                                         node_featurizer=featurize_atoms,
                                         canonical_atom_order=True)

    return dgl_graph


def featurize_atoms(mol):
    feats = []
    atom_features = utils.ConcatFeaturizer([
        utils.atom_type_one_hot,
        utils.atomic_number_one_hot,
        utils.atom_degree_one_hot,
        utils.atom_explicit_valence_one_hot,
        utils.atom_formal_charge_one_hot,
        utils.atom_num_radical_electrons_one_hot,
        utils.atom_hybridization_one_hot,
        utils.atom_is_aromatic_one_hot
    ])

    for atom in mol.GetAtoms():
        feats.append(atom_features(atom))

    return {'feats': torch.tensor(feats).float()}


def featurize_bonds(mol):
    feats = []
    bond_features = utils.ConcatFeaturizer([
        utils.bond_type_one_hot,
        utils.bond_is_conjugated_one_hot,
        utils.bond_is_in_ring_one_hot,
        utils.bond_stereo_one_hot,
        utils.bond_direction_one_hot,
    ])

    for bond in mol.GetBonds():
        feats.append(bond_features(bond))
        feats.append(bond_features(bond))
    return {'edge_feats': torch.tensor(feats).float()}


def split_dataset(df, random_seed, split_ratio=(0.8, 0.1, 0.1)):
    train_ratio, val_ratio, test_ratio = split_ratio
    assert train_ratio + val_ratio + test_ratio == 1

    # Randomly scrambled data
    df = df.sample(frac=1, random_state=random_seed).reset_index(drop=True)
    df['graph'] = df['SMILES'].apply(lambda x: create_dgl_features(x))

    train_size = int(train_ratio * len(df))
    val_size = int(val_ratio * len(df))

    train_df = df[:train_size]
    val_df = df[train_size:train_size + val_size]
    test_df = df[train_size + val_size:]

    train_df = train_df.reset_index(drop=True)
    val_df = val_df.reset_index(drop=True)
    test_df = test_df.reset_index(drop=True)

    return train_df, val_df, test_df


# The number of augmentations is specified to generate the augmented dataset
def augment(train_df, num_augment, random_seed, use_atom_mask=True, use_edge_delete=True):
    if use_atom_mask:
        atom_transformer = RandomAtomMask()
    if use_edge_delete:
        edge_transformer = RandomBondDelete()

    new_dfs = []
    for index, row in train_df.iterrows():
        np.random.seed(random_seed)
        for i in [random.randint(1, 100) for _ in range(num_augment)]:
            row_copy = row.copy()
            if use_atom_mask:
                aug_mol_graph = atom_transformer.apply_transform(row_copy['graph'], i)
                row_copy['graph'] = aug_mol_graph

            if use_edge_delete:
                aug_mol_graph = edge_transformer.apply_transform(row_copy['graph'], i)
                row_copy['graph'] = aug_mol_graph
            new_dfs.append(row_copy)
    data = pd.DataFrame(new_dfs)
    data = pd.concat([train_df, data])

    data = data.sample(frac=1, random_state=random_seed).reset_index(drop=True)
    print(f"-------Augment the data {num_augment} times-------")
    return data


def train(encoder, regressor, train_loader, val_loader, criterion, optimizer,
          num_epochs, encod_save_path, regre_save_path, step_size, gamma, patience):
    train_losses = []
    val_losses = []
    best_val_loss = float('inf')
    scheduler = StepLR(optimizer, step_size=step_size, gamma=gamma)

    patience = patience
    counter = 0

    for epoch in range(num_epochs):
        encoder.train()
        regressor.train()
        train_loss = 0.0
        for batch_idx, (graphs, labels) in enumerate(train_loader):
            node_feats = graphs.ndata['feats']
            edge_feats = graphs.edata['edge_feats']

            h = encoder(graphs, node_feats, edge_feats)
            outputs = regressor(h)
            outputs = outputs.to(torch.float32)
            labels = labels.to(torch.float32)

            loss = criterion(outputs, labels)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            train_loss += loss.item() * len(labels)

        scheduler.step()

        encoder.eval()
        regressor.eval()
        val_loss = 0.0
        with torch.no_grad():
            for batch_idx, (graphs, labels) in enumerate(val_loader):
                node_feats = graphs.ndata['feats']
                edge_feats = graphs.edata['edge_feats']
                h = encoder(graphs, node_feats, edge_feats)
                outputs = regressor(h)

                outputs = outputs.to(torch.float32)
                labels = labels.to(torch.float32)

                loss = criterion(outputs, labels)

                val_loss += loss.item() * len(labels)

            train_loss /= len(train_loader.dataset)
            val_loss /= len(val_loader.dataset)

            print('Epoch [{}/{}], Train Loss: {:.4f}, Val Loss: {:.4f}'.format(epoch + 1, num_epochs, train_loss,
                                                                               val_loss))
            train_losses.append(train_loss)
            val_losses.append(val_loss)

            # Save the best model
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                counter = 0
                torch.save(encoder.state_dict(), encod_save_path)
                torch.save(regressor.state_dict(), regre_save_path)
            else:
                counter += 1

        if counter >= patience:
            print('Early stopping: Training stopped at epoch', epoch + 1)
            break

    plt.style.use('classic')
    plt.rcParams["font.family"] = "Times New Roman"
    plt.rcParams['font.size'] = 20
    plt.figure()
    plt.plot(train_losses, label='Train Loss')
    plt.plot(val_losses, linestyle='--', label='Val Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')

    legend = plt.legend(fontsize=16)
    legend.set_frame_on(False)
    legend.get_frame().set_alpha(0)

    plt.show()


def test(encoder, regressor, test_loader, train_loader, val_loader, encod_save_path, regre_save_path):
    encoder.load_state_dict(torch.load(encod_save_path))
    regressor.load_state_dict(torch.load(regre_save_path))

    encoder.eval()
    regressor.eval()
    y_true = []
    y_pred = []
    with torch.no_grad():
        for batch_idx, (graphs, labels) in enumerate(test_loader):
            node_feats = graphs.ndata['feats']
            edge_feats = graphs.edata['edge_feats']
            h = encoder(graphs, node_feats, edge_feats)
            outputs = regressor(h)

            outputs = outputs.to(torch.float32)
            labels = labels.to(torch.float32)

            y_true.extend(labels.cpu().numpy())
            y_pred.extend(outputs.cpu().numpy())

            y_pred = list(map(float, y_pred))

    mse = mean_squared_error(y_true, y_pred)
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_true, y_pred)
    aare = np.mean(np.abs((np.array(y_true) - np.array(y_pred)) / np.array(y_true)))

    print('Test MAE: {:.4f}'.format(mae))
    print('Test RMSE: {:.4f}'.format(rmse))
    print('Test R²: {:.4f}'.format(r2))
    print('Test AARE: {:.4f}'.format(aare))

    encoder.eval()
    regressor.eval()

    train_y_true = []
    train_y_pred = []

    with torch.no_grad():
        for batch_idx, (graphs, labels) in enumerate(train_loader):
            node_feats = graphs.ndata['feats']
            edge_feats = graphs.edata['edge_feats']
            h = encoder(graphs, node_feats, edge_feats)
            outputs = regressor(h)

            outputs = outputs.to(torch.float32)
            labels = labels.to(torch.float32)

            train_y_true.extend(labels.cpu().numpy())
            train_y_pred.extend(outputs.cpu().numpy())

    train_y_pred = list(map(float, train_y_pred))

    train_mse = mean_squared_error(train_y_true, train_y_pred)
    train_mae = mean_absolute_error(train_y_true, train_y_pred)
    train_rmse = np.sqrt(train_mse)
    train_r2_score = r2_score(train_y_true, train_y_pred)
    train_aare = np.mean(np.abs((np.array(train_y_true) - np.array(train_y_pred)) / np.array(train_y_true)))

    print('Train MAE: {:.4f}'.format(train_mae))
    print('Train RMSE: {:.4f}'.format(train_rmse))
    print('Train R²: {:.4f}'.format(train_r2_score))
    print('Train AARE: {:.4f}'.format(train_aare))

    encoder.eval()
    regressor.eval()

    val_y_true = []
    val_y_pred = []

    with torch.no_grad():
        for batch_idx, (graphs, labels) in enumerate(val_loader):
            node_feats = graphs.ndata['feats']
            edge_feats = graphs.edata['edge_feats']
            h = encoder(graphs, node_feats, edge_feats)
            outputs = regressor(h)

            outputs = outputs.to(torch.float32)
            labels = labels.to(torch.float32)

            val_y_true.extend(labels.cpu().numpy())
            val_y_pred.extend(outputs.cpu().numpy())

    val_y_pred = list(map(float, val_y_pred))

    val_mse = mean_squared_error(val_y_true, val_y_pred)
    val_mae = mean_absolute_error(val_y_true, val_y_pred)
    val_rmse = np.sqrt(val_mse)
    val_r2_score = r2_score(val_y_true, val_y_pred)
    val_aare = np.mean(np.abs((np.array(val_y_true) - np.array(val_y_pred)) / np.array(val_y_true)))

    print('Val MAE: {:.4f}'.format(val_mae))
    print('Val RMSE: {:.4f}'.format(val_rmse))
    print('Val R²: {:.4f}'.format(val_r2_score))
    print('Val AARE: {:.4f}'.format(val_aare))

    plt.style.use('classic')
    plt.rcParams["font.family"] = "Times New Roman"
    plt.rcParams['font.size'] = 20

    plt.scatter(y_true, y_pred, label='test', marker='o', edgecolor='blue', facecolor='none')
    plt.scatter(train_y_true, train_y_pred, label='Train', marker='s', edgecolor='green', facecolor='none')
    plt.scatter(val_y_true, val_y_pred, label='Validation', marker='^', edgecolor='red', facecolor='none')

    plt.xlabel('Experimental [K]')
    plt.ylabel('Predicted [K]')

    max_value = max([max(y_true), max(y_pred), max(train_y_true),
                     max(train_y_pred), max(val_y_true), max(val_y_true)])
    yy = range(0, int(max_value + 1), 1)
    plt.plot(range(0, int(max_value + 1), 1), yy, c='gray', linestyle='--')

    legend = plt.legend(fontsize=16, loc='best')
    legend.set_frame_on(False)
    legend.get_frame().set_alpha(0)

    plt.show()

    return {
        'train': {
            'MAE': train_mae,
            'RMSE': train_rmse,
            'R2': train_r2_score,
            'AARE': train_aare
        },
        'test': {
            'MAE': mae,
            'RMSE': rmse,
            'R2': r2,
            'AARE': aare
        },
        'val': {
            'MAE': val_mae,
            'RMSE': val_rmse,
            'R2': val_r2_score,
            'AARE': val_aare
        }
    }


class MolecularDataset(Dataset):
    def __init__(self, df):
        self.data = df

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        graph = self.data['graph'][idx]
        label = self.data['AIT (K)'][idx]
        return graph, label
