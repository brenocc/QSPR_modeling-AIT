import dgl
from dgl.nn.pytorch.conv import GraphConv
import torch
import torch.nn as nn
import torch.nn.functional as F


class MPNNEncoder(nn.Module):
    def __init__(self, node_in_feats=177, edge_in_feats=17, node_out_feats=256,
                 num_step_set2set=3, num_layer_set2set=2, num_message_passing=3):
        super(MPNNEncoder, self).__init__()
        self.node_emb = nn.Linear(node_in_feats, node_out_feats)
        self.edge_emb = nn.Linear(edge_in_feats, node_out_feats)
        self.gru = nn.GRU(node_out_feats * 2, node_out_feats)
        self.readout = dgl.nn.pytorch.glob.Set2Set(node_out_feats, n_iters=num_step_set2set, n_layers=num_layer_set2set)
        self.num_message_passing = num_message_passing

    def forward(self, g, node_feats, edge_feats):
        g.ndata['h'] = self.node_emb(node_feats)
        g.edata['e'] = self.edge_emb(edge_feats)

        for i in range(self.num_message_passing):
            # Message passing
            g.update_all(message_func=dgl.function.u_mul_e('h', 'e', 'm'),
                         reduce_func=dgl.function.sum('m', 'h_sum'))
            # GRU for updating nodes features
            h = g.ndata['h']
            h_sum = g.ndata['h_sum']
            _, h_new = self.gru(torch.cat([h.unsqueeze(0), h_sum.unsqueeze(0)], dim=2))
            g.ndata['h'] = h_new.squeeze(0)

        output = self.readout(g, g.ndata['h'])

        return output


class Regressor(nn.Module):
    def __init__(self, input_channels=512, hidden_channels=256, output_channels=1):
        super(Regressor, self).__init__()
        self.fc1 = nn.Linear(input_channels, hidden_channels)
        self.fc2 = nn.Linear(hidden_channels, hidden_channels // 2)
        self.fc3 = nn.Linear(hidden_channels // 2, output_channels)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x
