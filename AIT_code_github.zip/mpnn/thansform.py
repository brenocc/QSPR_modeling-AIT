import math
import random
from copy import deepcopy
import dgl
import torch


class BaseTransform(object):
    def __init__(self, prob: float = 0.1):
        """
        @param p: the probability of the transform being applied; default value is 0.1. If
                  a list is passed in, the value will be randomly and sampled between the two
                  end points.
        """
        if (isinstance(prob, list)):
            assert 0 <= prob[0] <= 1.0
            assert 0 <= prob[1] <= 1.0
            assert prob[0] < prob[1]
        else:
            assert 0 <= prob <= 1.0, "p must be a value in the range [0, 1]"
        self.prob = prob

    def __call__(self, mol_graph: dgl.graph, seed=None) -> dgl.graph:
        """
        @param mol_graph: DGL graph to be augmented
        @param metadata: if set to be a list, metadata about the function execution
            including its name, the source & dest width, height, etc. will be appended to
            the inputted list. If set to None, no metadata will be appended or returned
        @returns: Augmented DGL Data
        """
        if (isinstance(self.prob, list)):
            self.p = random.uniform(self.prob[0], self.prob[1])  # 随机生成一个实数范围在 prob[0],prob[1]之间
        else:
            self.p = self.prob
        assert isinstance(self.p, (float, int))
        return self.apply_transform(mol_graph, seed)

    def apply_transform(self, mol_graph: dgl.graph, seed) -> dgl.graph:
        """
        This function is to be implemented in the child classes.
        From this function, call the augmentation function with the
        parameters specified
        """
        raise NotImplementedError()


class RandomAtomMask(BaseTransform):
    def __init__(self, p: float = 0.1):
        """
        @param p: the probability of the transform being applied; default value is 0.1
        """
        super().__init__(prob=p)
        self.p = p

    def apply_transform(self, mol_graph: dgl.graph, seed) -> dgl.graph:
        """
        Transform that randomly mask atoms given a certain ratio
        @param mol_graph: DGL graph to be augmented
        @param seed:
        @returns: Augmented dgl graph
        """

        random.seed(seed)
        N = mol_graph.num_nodes()  # 分子图中的节点数量
        if N > 5:
            num_mask_nodes = max([1, math.floor(self.p * N)])  # 需要遮掩的节点数量
            mask_nodes_index = random.sample(list(range(N)), num_mask_nodes)  # 随机选取需要遮盖的节点的索引列表

            aug_mol_graph = deepcopy(mol_graph)  # 复制mol_graph,在这个复制对象进行节点遮掩
            aug_mol_graph = mask_nodes(aug_mol_graph, mask_nodes_index)
        else:
            aug_mol_graph = mol_graph
            mask = torch.zeros(N)
            aug_mol_graph.ndata['mask'] = mask.unsqueeze(1)
        return aug_mol_graph

    def __str__(self):
        return "RandomAtomMask(p = {})".format(self.p)


def mask_nodes(graph, mask_node_idx):
    mask = torch.zeros(graph.num_nodes())
    mask[mask_node_idx] = 1
    graph.ndata['mask'] = mask.unsqueeze(1)
    graph.ndata['feats'] = graph.ndata['feats'] * (1 - mask.unsqueeze(1))
    return graph


class RandomBondDelete(BaseTransform):
    def __init__(self, p: float = 0.1):
        """
        @param p: the probability of the transform being applied; default value is 1.0
        """
        super().__init__(prob=p)
        self.p = p

    def apply_transform(self, mol_graph: dgl.graph, seed) -> dgl.graph:
        """
        Transform that randomly delete chemical bonds given a certain ratio
        @param mol_graph: DGL graph to be augmented
        @returns: Augmented DGL graph
        """

        random.seed(seed)
        M = mol_graph.num_edges()
        if M > 5:
            num_mask_edges = max([0, math.floor(self.p * M)])
            mask_edges_index = random.sample(list(range(M)), num_mask_edges)
            aug_mol_graph = deepcopy(mol_graph)
            aug_mol_graph = mask_edges(aug_mol_graph, mask_edges_index)
        else:
            aug_mol_graph = mol_graph
            mask = torch.zeros(M)
            aug_mol_graph.edata['mask'] = mask.unsqueeze(1)

        return aug_mol_graph

    def __str__(self):
        return "RandomBondDelete(p = {})".format(self.prob)


def mask_edges(graph, mask_edges_idx):
    mask = torch.zeros(graph.num_edges())
    mask[mask_edges_idx] = 1
    graph.edata['mask'] = mask.unsqueeze(1)
    graph.edata['edge_feats'] = graph.edata['edge_feats'] * (1 - mask.unsqueeze(1))
    return graph
