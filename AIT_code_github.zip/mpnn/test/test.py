import pandas as pd
from dgl.dataloading import GraphDataLoader
from torch import nn, optim
from model.MPNN import MPNNEncoder, Regressor

from util import train, test, MolecularDataset, split_dataset, augment

output_path = './evaluation_results.xlsx'
writer = pd.ExcelWriter(output_path, engine='xlsxwriter')
results_dict = {
            'train': {
            'MAE': [],
            'RMSE':[],
            'R2':[] ,
            'AARE':[]
        },
        'test': {
             'MAE': [],
            'RMSE':[],
            'R2':[] ,
            'AARE':[]
        },
        'val': {
             'MAE': [],
            'RMSE':[],
            'R2':[] ,
            'AARE':[]
        }
}

for i in range(10):
    seed = i + 1
    file_dir='../../data/init_data.xlsx'
    df = pd.read_excel(file_dir, 'Pre-screening')

    train_df, val_df, test_df = split_dataset(df, seed)

    train_data = MolecularDataset(train_df)
    val_data = MolecularDataset(val_df)
    test_data = MolecularDataset(test_df)
    train_loader = GraphDataLoader(train_data, batch_size=1, shuffle=True)
    val_loader = GraphDataLoader(val_data, batch_size=1, shuffle=True)
    test_loader = GraphDataLoader(test_data, batch_size=1, shuffle=True)

    node_out_feats = 512
    num_step_set2set = 1
    num_layer_set2set = 1
    num_message_passing = 1

    encoder = MPNNEncoder(node_in_feats=177, edge_in_feats=17, node_out_feats=node_out_feats,
                          num_step_set2set=num_step_set2set, num_layer_set2set=num_layer_set2set,
                          num_message_passing=num_message_passing)
    regressor = Regressor(input_channels=node_out_feats * 2, hidden_channels=node_out_feats, output_channels=1)
    optimizer = optim.Adam(list(encoder.parameters()) + list(regressor.parameters()), lr=0.0001)
    criterion = nn.MSELoss()

    train(encoder, regressor, train_loader, val_loader, criterion, optimizer, num_epochs=20,
          encod_save_path='_path/encoder_{}.pth'.format(seed), regre_save_path='_path/regressor_{}.pth'.format(seed),step_size=10,
          gamma=0.1,patience=10)

    result = test(encoder, regressor, test_loader, train_loader, val_loader,
                  encod_save_path='_path/encoder_{}.pth'.format(seed),
                  regre_save_path='_path/regressor_{}.pth'.format(seed))

    for key in results_dict.keys():
        for metric, value in result[key].items():
            results_dict[key][metric].append(value)

for key, value in results_dict.items():
    df = pd.DataFrame(value)
    df.to_excel(writer, sheet_name=key, index=False)

writer._save()
writer.close()

